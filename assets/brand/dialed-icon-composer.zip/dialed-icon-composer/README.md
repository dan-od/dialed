# Dialed — Icon Composer layers

Icon Composer (Apple, free, macOS) turns flat layers into a Liquid Glass app icon.

1. Open Icon Composer → New. Canvas is 1024 × 1024.
2. Background: Fill → Gradient, top #FF7E45 → bottom #F0480F (or solid #FF5A1F).
3. Drag in `1-knob.svg`, then `2-stem.svg` above it, as two separate groups. Keeping them separate is what gives the depth: the stem floats over the knob.
4. For each group, turn on Liquid Glass. Start with Translucency ~40%, Shadow: Neutral, Specular: on.
5. Appearances:
   - Dark: background #140A05 → #2B1A12, layer fill #FF5A1F.
   - Clear / Tinted: let the system handle it; check that the slot in the knob still reads.
6. Export `Dialed.icon` and drag it into the Xcode project (Expo: point `ios.icon` at it in app.json, SDK 54+).

Layer fills are ink #140A05. The geometry is the small-size cut (fatter indicator slot).
